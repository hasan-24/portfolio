<!doctype html>
<html lang="en">
<head>
        <title>Md. Mahmudul Hasan</title>

        <!-- META TAGS   -->
        <meta http-equiv="Cache-Control" content="no-cache">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name='robots' content='noindex,follow' />
        <meta name="country" content="BD" />
        <meta name="description" content="Md. Mahmudul Hasan" />
        <meta name="keywords" content="samrat, mahmudul hasan, mahmudul hasan samrat,  developer, designer, network engineer, security engineer, mahmudul hasan portfolio" />
        <meta name="developer" content="Md. Mahmudul Hasan">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- FAV AND ICONS   -->
        <link rel="shortcut icon" href="assets/images/favicon.png">        
        <!-- Google Font-->
        <link href="http://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <!-- Custom CSS-->
        <link rel="stylesheet" href="assets/icons/font-awesome-4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/plugins/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/plugins/css/animate.css">
        <link rel="stylesheet" href="assets/plugins/css/owl.css">
        <link rel="stylesheet" href="assets/plugins/css/jquery.fancybox.min.css">
        <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        <link rel="stylesheet" href="assets/css/orange.css" title="defauld">
    </head>

    <body class="dark-vertion home-video black-bg">
        
        <!-- Start Loader -->
        <div class="section-loader">
            <div class="loader">
                <div></div>
                <div></div> 
            </div>
        </div>
        <!-- End Loader -->
        
        <!--NAVIGATION-->
        <header class="black-bg mh-header mh-fixed-nav nav-scroll mh-xs-mobile-nav" id="mh-header">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-expand-lg mh-nav nav-btn">                        
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-0 ml-auto">
                                <li class="nav-item">
                                    <img src="assets/images/fedalon_logo.png" alt="" class="img-fluid" style="max-height: 22px; margin-top: 12px;">
                                </li>
                                <br>
                                <li class="nav-item active">
                                    <a class="nav-link" href="#mh-home">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#mh-about">About</a>
                                </li>
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-skills">Skills</a>
                                </li>                                
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-experience">Cognition</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#mh-blog">Achievement</a>
                                </li>                                
                                <li class="nav-item">
                                    <a class="nav-link" href="#mh-portfolio">Portfolio</a>
                                </li> 
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-contact">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>

        <!--Home -->
        <section class="mh-home image-bg relative" id="mh-home">
            <div class="img-foverlay img-color-overlay">
                <div class="section-video">
                    <video autoplay="" class="bgvid" loop="" muted="">
                        <source src="assets/ban.mp4" type="video/mp4">
                    </video>
                </div>
                <div class="container">
                    <div class="row section-separator xs-column-reverse vertical-middle-content home-padding">
                        <div class="col-sm-6">
                            <div class="mh-header-info">
                                <div class="mh-promo wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.1s">
                                    <span>Hello! I'm</span>
                                </div>
                                
                                <h2 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Md. Mahmudul Hasan</h2>
                                <h4 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">Designer | Developer</h4>
                                
                                <ul>
                                    <li class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s"><i class="fa fa-phone"></i><a href="callto:">+880 1873472524</a></li>
                                    <li class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s"><i class="fa fa-envelope"></i><a href="mailto:">mahmudulhasan.2524@gmail.com</a></li>
                                    <li class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.6s"><i class="fa fa-map-marker"></i><address>1A/634, Mirpur DOHS, Dhaka, Bangladesh</address></li>
                                </ul>
                                
                                <ul class="social-icon wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                                    <li><a href="https://linkedin.com/in/hasan24" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="https://github.com/hasan-24" target="_blank"><i class="fa fa-github"></i></a></li>
                                    <li><a href="https://wa.me/8801873472524" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
                                    <li><a data-fancybox data-src="#wechat"><i class="fa fa-wechat"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="hero-img wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.6s">
                                <div class="img-border">
                                    <img src="assets/images/hero.png" alt=""  class="img-fluid">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--ABOUT -->
        <section class="mh-about" id="mh-about">
            <div class="container">
                <div class="row section-separator">
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-img shadow-2 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s">
                            <img src="assets/images/ab-img.png" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-inner">
                            <h2 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.1s">About Me</h2>
                            <p class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Hi! I'm Mahmudul Hasan. A proud Ex-Cadet, and of course- a dreamer for a better planet.<br>
                            I'm studying B.Sc. in Information & Communication Engineering from Bangladesh University of Professionals (BUP). I'm interested & wizard in Security, Networking, Robotics, IoT, Blockchain, Graphic, Website & Web apps.
                            </p>
                            <div class="mh-about-tag wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                <ul>
                                    <li><span>C</span></li>
                                    <li><span>C++</span></li>
                                    <li><span>Java</span></li>
                                    <li><span>Kotlin</span></li>
                                    <li><span>Python</span></li>
                                    <li><span>Shell</span></li>
                                    <li><span>SQL</span></li>
                                    <li><span>HTML</span></li>
                                    <li><span>CSS</span></li>
                                    <li><span>JavaScript</span></li>
                                    <li><span>PHP</span></li>

                                </ul>
                            </div>
                            <a href="https://drive.google.com/file/d/14DO6jn-J6Nas6tv9dYHag_onCzqjj-aB/view?usp=sharing" target="_blank" class="btn btn-fill wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s">Get my CV<i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- WHAT I DO-->
        <section class="mh-service image-bg featured-img-two">
            <div class="container">
                <div class="row section-separator">
                    <div class="col-sm-12 text-center section-title wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                        <h2>What I do</h2>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                            <i class="fa fa-lock lock-color"></i>
                            <h3>Network & Security</h3>
                            <p>
                                Network Configuration-Infrastructure & Topology, Server management, Lookup, PenTest, Security Assessment
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                            <i class="fa fa-cloud cloud-color"></i>
                            <h3>IoT</h3>
                            <p>
                                VMware, Arduino, Raspberry Pi, Cloud Integration, Sensor & M2M Communication, LoWPAN, API, Backhaul, BLE, IIOT, LPWA, SDN
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                            <i class="fa fa-film media-color"></i>
                            <h3>Graphic Design & Content</h3>
                            <p>
                                Logo, UI, Products, Content<br>
                                Tools: Adobe- Photoshop, Illustrator, After Effects, Premier Pro
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                            <i class="fa fa-code code-color"></i>
                            <h3>Website & Web Application</h3>
                            <p>
                                Wordpress, Bootstrap, PHP, Laravel, Django
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                            <i class="fa fa-spinner robotics-color"></i>
                            <h3>Robotics</h3>
                            <p>
                                LFR, RC, Cobots, Cloud Robotics, Sensor-based robotics
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4" style="margin-top: 25px;">
                        <div class="mh-service-item shadow-1 dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                            <i class="fa fa-object-ungroup blockchain-color"></i>
                            <h3>Blockchain</h3>
                            <p>
                                Corda R3, Hyperledger Fabric
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--SKILLS -->
        <section class="mh-skills" id="mh-skills">
            <div class="home-v-img">
                <div class="container">
                    <div class="row section-separator">
                        <div class="section-title text-center col-sm-12">
                            <!--<h2>Skills</h2>-->
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-skills-inner">
                                <div class="mh-professional-skill wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                    <h3>Technical Skills</h3>
                                    <div class="each-skills">
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">C, C++</div>
                                                    <div class="percentagem-num">86%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 86%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">Java</div>
                                                    <div class="percentagem-num">46%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 46%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">Kotlin</div>
                                                    <div class="percentagem-num">38%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 38%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">Python</div>
                                                    <div class="percentagem-num">17%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 17%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">Shell</div>
                                                    <div class="percentagem-num">46%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 46%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">SQL</div>
                                                    <div class="percentagem-num">76%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 76%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">HTML, CSS, JavaScript</div>
                                                    <div class="percentagem-num">67%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 67%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="candidatos">
                                            <div class="parcial">
                                                <div class="info">
                                                    <div class="nome">PHP</div>
                                                    <div class="percentagem-num">47%</div>
                                                </div>
                                                <div class="progressBar">
                                                    <div class="percentagem" style="width: 47%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-professional-skills wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                <h3>Professional Skills</h3>
                                <ul class="mh-professional-progress">
                                    <li>
                                        <div class="mh-progress mh-progress-circle" data-progress="80"></div>
                                        <div class="pr-skill-name">Communication</div>
                                    </li>
                                    <li>
                                        <div class="mh-progress mh-progress-circle" data-progress="55"></div> 
                                        <div class="pr-skill-name">Team Work</div>
                                    </li>
                                    <li>
                                        <div class="mh-progress mh-progress-circle" data-progress="65"></div>
                                        <div class="pr-skill-name">Project Management</div>
                                    </li> 
                                    <li>
                                        <div class="mh-progress mh-progress-circle" data-progress="85"></div>
                                        <div class="pr-skill-name">Creativity</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--EXPERIENCES -->
        <section class="mh-experince image-bg featured-img-one" id="mh-experience">
            <div class="img-color-overlay">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 ">
                            <div class="mh-education">
                                <h3 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Experience</h3>
                                <div class="mh-education-deatils">
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                        <h4>Internship on Advanced Blockchain Development at <a href="http://www.technohaven.com" target="_blank">Technohaven Ltd.</a></h4>
                                        <div class="mh-eduyear">Jun-August, 2020</div>
                                        <p>Advanced Blockchain Training & Internship by- LICT Bangladesh & Hongkong Blockchain Society.</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#exp1" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br><br>
                            <div class="mh-education">
                                <h3 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Education</h3>
                                <div class="mh-education-deatils">
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                        <h4>B.Sc. in Information & Communication Engineering(ICE)<br><a href="https://bup.edu.bd" target="_blank">Bangladesh University of Professionals(BUP)<br>Mirpur Cantonment, Dhaka, Bangladesh</a></h4>
                                        <div class="mh-eduyear">2017-Present</div>
                                        <p>Current CGPA: 3.4 </p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#edu1" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>JSC, SSC & HSC<br><a href="https://jcc.army.mil.bd" target="_blank">Jhenidah Cadet College<br>Jhenidah, Bangladesh</a></h4>
                                        <div class="mh-eduyear">2010-2016</div>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i> HSC: 5.00/5.00 (All Subjects)</li>
                                            <li><i class="fa fa-circle"></i> SSC: 5.00/5.00 (All Subjects)</li>
                                            <li><i class="fa fa-circle"></i> JSC: 5.00/5.00 (All Subjects)</li>
                                        </ul>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#edu2" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>                         
                                </div>
                            </div>
                            <br><br>
                            <div class="mh-education">
                                <h3 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Training & Certifications</h3>
                                <div class="mh-education-deatils">
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                        <h4>ICSI | CNSS Certified Network Security Specialist<br><a href="https://www.credential.net/274497d2-c2cb-4a89-a0f5-4ee388946c83" target="_blank">ICSI (International CyberSecurity Institute), UK</a></h4>
                                        <div class="mh-eduyear">July, 2020</div>
                                        <p>Credential Number: 20346651</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg1" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>NSE 2 Network Security Associate<br><a href="https://training.fortinet.com/mod/customcert/verify_certificate.php" target="_blank">Fortinet NSE Institute</a></h4>
                                        <div class="mh-eduyear">Validity: 2020-2022</div>
                                        <p>Certification Number: xtWMuohcRt</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg2" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>System Administration and IT Infrastructure Services<br><a href="https://www.coursera.org/account/accomplishments/verify/GD82TJYRNUBS" target="_blank">Google, Coursera</a></h4>
                                        <div class="mh-eduyear">December, 2019</div>
                                        <p>Credential ID: GD82TJYRNUBS</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg3" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>Autopsy Basics & Hands On<br><a href="https://training.autopsy.com/certificates/0lk0j0cmpg" target="_blank">Autopsy, Basis Technology</a></h4>
                                        <div class="mh-eduyear">July, 2020</div>
                                        <p>Credential ID: 0lk0j0cmpg</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg4" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>Advanced Google Analytics<br><a href="https://analytics.google.com/analytics/academy/certificate/TU8f8M6PTrOfg1pYYwcxkQ" target="_blank">Google Analytics Academy</a></h4>
                                        <div class="mh-eduyear">Validity: 2019-2022</div>
                                        <p>Certificate Serial: TU8f8M6PTrOfg1pYYwcxkQ</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg5" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>Fundamentals of Digital Marketing<br><a href="HTTPS://GOO.GL/Tjymo6" target="_blank">Google Digital Garage</a></h4>
                                        <div class="mh-eduyear">February, 2019</div>
                                        <p>Certificate ID: 3Q9 CUS ZCR</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg6" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                        <h4>Microsoft Office Fundamentals<br><a href="https://courses.edx.org/certificates/9af4902b25044ba0b41b73879563d3bf" target="_blank">Microsoft, EDx</a></h4>
                                        <div class="mh-eduyear">September, 2019</div>
                                        <p>Certificate ID: 2775be2e445642f9a9fc999105032724</p>
                                        <div class="mh-photo">
                                            <a data-fancybox data-src="#trg7" class="btn btn-fill wow fadeInUp">View  <i class="fa fa-file"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mh-portfolio-modal" id="exp1">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/exp1.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="edu1">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/edu1.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="edu2">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/edu201.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg1">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg1.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg2">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg2.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg3">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg3.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg4">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg4.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg5">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg5.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg6">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg6.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="trg7">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/cert/trg7.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>

        </section>       

        <!--ACHIEVEMENTS-->
        <section class="mh-blog image-bg featured-img-two" id="mh-blog">
            <div class="img-color-overlay">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                            <h3>Achievements</h3>
                        </div>
                        <div class="col-sm-12 col-md-4">
                             <div class="mh-blog-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                                <img src="assets/images/achievement1.jpg" alt="" class="img-fluid">
                                <div class="blog-inner">
                                    <h2><a >Champion in Poster Presentation</a></h2>
                                    <div class="mh-blog-post-info">
                                        <ul>
                                            <li><a >EEE Day'19, Independent University Bangladesh (IUB)</a></li>
                                        </ul>
                                    </div>
                                    <p>Topic: Feeling Sensing & Movement Tracking Bracelet using Deep Learning Algorithm.</p>
                                </div>
                        </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="mh-blog-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                                <img src="assets/images/achievement2.jpg" alt="" class="img-fluid">
                                <div class="blog-inner">
                                    <h2><a >2nd Runner-Up in Project Showcasing</a></h2>
                                    <div class="mh-blog-post-info">
                                        <ul>
                                            <li><a >Techsurgence'19, Bangladesh University of Professionals (BUP)</a></li>
                                        </ul>
                                    </div>
                                    <p>Topic: Automatic Driver & Vehicle Papers Checker using RF Technology.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="mh-blog-item dark-bg wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.7s">
                                <img src="assets/images/achievement3.jpg" alt="" class="img-fluid">
                                <div class="blog-inner">
                                    <h2><a >Semi Finalist (5th) in Robo Race</a></h2>
                                    <div class="mh-blog-post-info">
                                        <ul>
                                            <li><a >Mecceleration’19, Islamic University of Technology (IUT)</a></li>
                                        </ul>
                                    </div>
                                    <p>Obstacle Robo Race<br>
                                    Control: RC</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> 
        
        
        <!--
        <section class="mh-testimonial" id="mh-testimonial">
            <div class="home-v-img">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                            <h3>Recommendations</h3>
                        </div>
                        <div class="col-sm-12 wow fadeInUp" id="mh-client-review" data-wow-duration="0.3s" data-wow-delay="0.3s">
                            <div class="each-client-item">
                                <div class="mh-client-item dark-bg black-shadow-1">
                                    <img src="assets/images/c-1.png" alt="" class="img-fluid">
                                    <p>Very potential and analytical mind. Expert in cybersecurity, surveillance & digital forensic.</p>
                                    <h4>Masud Ahmed</h4>
                                    <span>SS, CID, Dhaka</span>
                                </div>
                            </div>
                            <div class="each-client-item">
                                <div class="mh-client-item dark-bg black-shadow-1">
                                    <img src="assets/images/c-2.png" alt="" class="img-fluid">
                                    <p>Creative & dedicated student. Possesses extensive research urge with interest. Participates in national contests with recognitions as representative of the university.</p>
                                    <h4>Dr. Mohammed Nasir Uddin</h4>
                                    <span>Associate Professor, Dept. of ICT<br>Bangladesh University of Professionals (BUP)</span>
                                </div>
                            </div>
                            <div class="each-client-item">
                                <div class="mh-client-item dark-bg black-shadow-1">
                                    <img src="assets/images/c-3.png" alt="" class="img-fluid">
                                    <p>Absolute workaholic personality. The core basics of IT fundamentals are very strong. Creates amazing IoT projects with learning habit.</p>
                                    <h4>Azmal Hossain</h4>
                                    <span>COO, Primus Technologies</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        Testimonial-->


        <!--PROJECTS-->
        <section class="mh-portfolio" id="mh-portfolio">
            <div class="container">
                <div class="row section-separator">
                    <div class="section-title col-sm-12 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.1s">
                        <h3>Portfolio</h3>
                    </div>
                    <div class="part col-sm-12">
                        <div class="portfolio-nav col-sm-12" id="filter-button">
                            <ul>
                                <li data-filter="*" class="current wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.1s"> <span>All Categories</span></li>
                                <li data-filter=".research" class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s"><span>Research</span></li>
                                <li data-filter=".programming" class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s"><span>Programming</span></li>
                                <li data-filter=".iot" class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s"><span>IoT</span></li>
                                <li data-filter=".robotics" class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s"><span>Robotics</span></li>
                                <li data-filter=".design" class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s"><span>Design</span></li>
                            </ul>
                        </div>
                        <div class="mh-project-gallery col-sm-12 wow fadeInUp" id="project-gallery" data-wow-duration="0.3s" data-wow-delay="0.5s">
                            <div class="portfolioContainer row">

                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 research">
                                    <figure>
                                        <img src="assets/images/portfolio/g1.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">UV-C Disinfectant Robot</h5>
                                            <a data-fancybox data-src="#research1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 programming">
                                    <figure>
                                        <img src="assets/images/portfolio/g2.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Web App Pentest- Movement Pass, BP</h5>
                                            <a data-fancybox data-src="#programming1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 iot">
                                    <figure>
                                        <img src="assets/images/portfolio/g3.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Smart Home & Office</h5>
                                            <a data-fancybox data-src="#iot1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 robotics">
                                    <figure>
                                        <img src="assets/images/portfolio/g4.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Line Follower Robot (LFR)</h5>
                                            <a data-fancybox data-src="#robotics1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 design">
                                    <figure>
                                        <img src="assets/images/portfolio/g5.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Logo Design</h5>
                                            <a data-fancybox data-src="#design1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 research">
                                    <figure>
                                        <img src="assets/images/portfolio/g6.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Health Monitor Bracelet</h5>
                                            <a data-fancybox data-src="#research2"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 programming">
                                    <figure>
                                        <img src="assets/images/portfolio/g7.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Website Development</h5>
                                            <a data-fancybox data-src="#programming2"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 iot">
                                    <figure>
                                        <img src="assets/images/portfolio/g8.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Vehicle License Checker with RFID</h5>
                                            <a data-fancybox data-src="#iot2"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 robotics">
                                    <figure>
                                        <img src="assets/images/portfolio/g9.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">AI Farming Assistant Robot</h5>
                                            <a data-fancybox data-src="#robotics2"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 design">
                                    <figure>
                                        <img src="assets/images/portfolio/g10.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Design- Branding & Promotion</h5>
                                            <a data-fancybox data-src="#design2"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 research">
                                    <figure>
                                        <img src="assets/images/portfolio/g11.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Smart Home & Office</h5>
                                            <a data-fancybox data-src="#research3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 programming">
                                    <figure>
                                        <img src="assets/images/portfolio/g12.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Android Application Development</h5>
                                            <a data-fancybox data-src="#programming3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 iot">
                                    <figure>
                                        <img src="assets/images/portfolio/g13.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Intruder Identification & Gun Fire</h5>
                                            <a data-fancybox data-src="#iot3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 robotics">
                                    <figure>
                                        <img src="assets/images/portfolio/g14.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">RC Robots</h5>
                                            <a data-fancybox data-src="#robotics3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 design">
                                    <figure>
                                        <img src="assets/images/portfolio/g15.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Products Design</h5>
                                            <a data-fancybox data-src="#design3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 design">
                                    <figure>
                                        <img src="assets/images/portfolio/g16.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Event Design</h5>
                                            <a data-fancybox data-src="#design4"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 design">
                                    <figure>
                                        <img src="assets/images/portfolio/g17.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <span class="sub-title">Details</span>
                                            <h5 class="title">Wireframe & UI Design</h5>
                                            <a data-fancybox data-src="#design5"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mh-portfolio-modal" id="research1">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>UV-C Disinfectant Robot</h2>
                            <p>Due to COVID-19 pandemic, ensuring safe and sterile equipment in office, school, college & universities became crying need. The goal can be achieved following 2 ways: cleaning with conventional disinfectant items, and sterilization & disinfection using UV-C light.</p>       
                            <p>In this situation, usage of UV-C light disinfectant may be the best option for cleaning.  There are three classes of UV light: UV-A, UV-B and UV-C. UV-C light (wavelength: 200-280nm), which has the most energy of all three types, is the most harmful, but it fortunately doesn't reach the Earth's surface because our atmosphere absorbs it.</p>
                            <p>There's man-made UV-C light, too: It's what's in the UV light sanitizers that companies claim kill the coronavirus. According to the National Academy of Sciences, it's probable that this is true, because UV light has been used to disinfect surfaces and water for a long time, and it's generally successful.  It works because UV-C light is strong enough to destroy the genetic material -- either DNA or RNA -- of viruses and bacteria. DNA is made of four bases: T=Thymine C=Cytosine A=Adenine G=Guanine. UV light causes two adjacent T bases to bond with each other, forming thymine dimers. Thymine dimers prevent DNA from being read correctly. If a cell's DNA develops too many thymine dimers, the cell will eventually die. In this way, UV light can kill bacteria, but it can also cause skin cancer in humans. So, the application of UV-C for sterilization should be done with absence of human being. For this, this paper proposes automated remote-controlled UV-C emitting robots for conducting this surface disinfection process. It is proven that, 5-10 minutes of exposure in UV-C kills any bacteria & virus including COVID-19.</p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>Indoor Usage of UV-C (200-280nm) zap for killing bacteria & virus</p>   
                                <img src="assets/images/portfolio/research101.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/research102.jpg" alt="" class="img-fluid">      
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="research2">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Health Monitor Bracelet</h2>
                            <p>"Health Monitor Bracelet" is the life saver smart device for babies, aged parents or handicapped persons (specially intellectual). In most of the cases, we fail to take care or track our children or aged parents 24/7 leaving them in unfortunate dangers like losing in street, falling in bathtub or near neighbor's pond. It contains GPS module, Stress Sensor, Pulse Rate Sensor, Temperature Sensor, Accelerometer, Shock Sensor, Oximeter Sensor and Sound Receiver. With the integration of all of the sensor values, the device can detect exact condition or feelings of the host body analyzing the data through deep learning algorithm.</p>       
                            <p>This Bracelet:
                                <ol style="list-style-type: disc;">
                                    <li>
                                        Can be implemented easily and availability of components in market with low cost
                                    </li>
                                    <li>
                                        Uses common wireless signal spectrum, no harmful effect for user
                                    </li>
                                    <li>
                                        Can be used by any kind of users & smart system works with both smart devices as well analog mobiles
                                    </li>
                                    <li>
                                        Frame can be made with fire and waterproof carbon fiber material for durability
                                    </li>
                                    <li>
                                        Can save unexpected injury or death of targeted subject in a wide range
                                    </li>
                                    <li>
                                        Real time tracking of targeted group of users becomes easy, affordable
                                    </li>
                                    <li>
                                        Provides freedom within tracking range for better mental and physical growth of children
                                    </li>
                                </ol>
                            </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>Flow Diagram:</p>
                                <img src="assets/images/portfolio/research201.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/research202.jpg" alt="" class="img-fluid">         
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="research3">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Automated Home & Office Infrastructure Management System</h2>
                            <p>Smart Office visualizes a thought of power saving, cost cutting and smooth-way of life. It introduces a thought of maintaining comfort, in-dependency and vital use of technology. Currently this automated office equipment controlling system is vastly being used. But this Smart Office has some extra feature, that is, it is controlled and specified by both manually and automatically using voice command, sensors and image processing. This device only works basing on a certain authority of a certain person of that designated place. According to the requirements the electric and digital applications will be used.</p>       
                            <p>Objectives:
                                <ol style="list-style-type: disc;">
                                    <li>
                                        Automatic sensor reduces human effort controlling all the appliances. It is difficult to control the utilities in broad places like: cafeteria, library, plaza, etc. 
                                    </li>
                                    <li>
                                        Can be controlled by smartphone device
                                    </li>
                                    <li>
                                        Can be controlled using voice command
                                    </li>
                                    <li>
                                        This system cuts off the heavy appliances from main power source, thus it saves unnecessary power consumption during standby mode or in absence of consumers
                                    </li>
                                    <li>
                                        Consists of power saving capacity which gives out and preserves the thought of green energy
                                    </li>
                                    <li>
                                        Consumes less of our time and restores the time that could’ve been wasted
                                    </li>
                                    <li>
                                        Reduction of manpower, less amount of load to think of manpower
                                    </li>
                                    <li>
                                        Other devices only detect and are controlled by app or only voice whereas we have both voice and manual command mode
                                    </li>
                                    <li>
                                        Camera and image processing built in for maintaining strict security
                                    </li>
                                    <li>
                                        Easier way to save power which will save small budgets of cost from everyday electricity bill
                                    </li>
                                    <li>
                                        Privacy and authority to check back on security
                                    </li>
                            </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>System Diagram:</p>  
                                <img src="assets/images/portfolio/iot101.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/iot102.jpg" alt="" class="img-fluid">       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="programming1">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Pentest & Security Checkup on Movement Pass System, Developed by ICT-Police HQ, Bangladesh</p>
                            <img src="assets/images/portfolio/programming101.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/programming102.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/programming103.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="programming2">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Website for Premier Sourcing Ltd.<br>Link: <a href="http://premiersourcingbd.com" target="_blank">www.premiersourcingbd.com</a></p>
                            <img src="assets/images/portfolio/programming201.jpg" style="max-width: 100%;"><br><br>
                            <p style="text-align: center;">Website for Trust Machineries Co., Ltd.<br>Link: <a href="https://trustmachineries.com" target="_blank">www.trustmachineries.com</a></p>
                            <img src="assets/images/portfolio/programming202.jpg" style="max-width: 100%;"><br><br>
                            <p style="text-align: center;">Website for SECL (Castrol- Bangladesh)<br>Link: <a href="https://seclbd.com" target="_blank">www.seclbd.com</a></p>
                            <img src="assets/images/portfolio/programming203.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="programming3">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Smart Home Project Controller App:</p>
                            <img src="assets/images/portfolio/programming301.jpg" style="max-width: 100%;"><br><br>
                            <p style="text-align: center;">Farmer Assistant Smart Robot App:</p>
                            <img src="assets/images/portfolio/programming302.jpg" style="max-width: 100%;"><br><br>
                            <p style="text-align: center;">RC Soccer Robot Controller App:</p>
                            <img src="assets/images/portfolio/programming303.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="iot1">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Automated Home & Office Infrastructure Management System</h2>
                            <p>Smart Office visualizes a thought of power saving, cost cutting and smooth-way of life. It introduces a thought of maintaining comfort, in-dependency and vital use of technology. Currently this automated office equipment controlling system is vastly being used. But this Smart Office has some extra feature, that is, it is controlled and specified by both manually and automatically using voice command, sensors and image processing. This device only works basing on a certain authority of a certain person of that designated place. According to the requirements the electric and digital applications will be used.</p>       
                            <p>Objectives:
                                <ol style="list-style-type: disc;">
                                    <li>
                                        Automatic sensor reduces human effort controlling all the appliances. It is difficult to control the utilities in broad places like: cafeteria, library, plaza, etc. 
                                    </li>
                                    <li>
                                        Can be controlled by smartphone device
                                    </li>
                                    <li>
                                        Can be controlled using voice command
                                    </li>
                                    <li>
                                        This system cuts off the heavy appliances from main power source, thus it saves unnecessary power consumption during standby mode or in absence of consumers
                                    </li>
                                    <li>
                                        Consists of power saving capacity which gives out and preserves the thought of green energy
                                    </li>
                                    <li>
                                        Consumes less of our time and restores the time that could’ve been wasted
                                    </li>
                                    <li>
                                        Reduction of manpower, less amount of load to think of manpower
                                    </li>
                                    <li>
                                        Other devices only detect and are controlled by app or only voice whereas we have both voice and manual command mode
                                    </li>
                                    <li>
                                        Camera and image processing built in for maintaining strict security
                                    </li>
                                    <li>
                                        Easier way to save power which will save small budgets of cost from everyday electricity bill
                                    </li>
                                    <li>
                                        Privacy and authority to check back on security
                                    </li>
                            </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>System Diagram:</p>  
                                <img src="assets/images/portfolio/iot101.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/iot102.jpg" alt="" class="img-fluid">       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="iot2">
                <div class="container">
                    <div class="mh-portfolio-modal-img">
                            <p style="text-align: center;">Automatic Driver & Vehicle Papers Checker using RF Technology:</p>
                            <style>.hytPlayerWrap{display: inline-block; position: relative;}.hytPlayerWrap.ended::after{content:""; position: absolute; top: 0; left: 0; bottom: 0; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 64px 64px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEwIDUxMCI+PHBhdGggZD0iTTI1NSAxMDJWMEwxMjcuNSAxMjcuNSAyNTUgMjU1VjE1M2M4NC4xNSAwIDE1MyA2OC44NSAxNTMgMTUzcy02OC44NSAxNTMtMTUzIDE1My0xNTMtNjguODUtMTUzLTE1M0g1MWMwIDExMi4yIDkxLjggMjA0IDIwNCAyMDRzMjA0LTkxLjggMjA0LTIwNC05MS44LTIwNC0yMDQtMjA0eiIgZmlsbD0iI0ZGRiIvPjwvc3ZnPg==);}.hytPlayerWrap.paused::after{content:""; position: absolute; top: 70px; left: 0; bottom: 50px; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 40px 40px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEiIHdpZHRoPSIxNzA2LjY2NyIgaGVpZ2h0PSIxNzA2LjY2NyIgdmlld0JveD0iMCAwIDEyODAgMTI4MCI+PHBhdGggZD0iTTE1Ny42MzUgMi45ODRMMTI2MC45NzkgNjQwIDE1Ny42MzUgMTI3Ny4wMTZ6IiBmaWxsPSIjZmZmIi8+PC9zdmc+);}</style><div class="hytPlayerWrapOuter"> <div class="hytPlayerWrap"> <iframe width="640" height="480" src="https://www.youtube.com/embed/ecZOUFeK0wQ?rel=0&enablejsapi=1" frameborder="0" ></iframe> </div></div><script>"use strict"; document.addEventListener('DOMContentLoaded', function(){if (window.hideYTActivated) return; let onYouTubeIframeAPIReadyCallbacks=[]; for (let playerWrap of document.querySelectorAll(".hytPlayerWrap")){let playerFrame=playerWrap.querySelector("iframe"); let tag=document.createElement('script'); tag.src="https://www.youtube.com/iframe_api"; let firstScriptTag=document.getElementsByTagName('script')[0]; firstScriptTag.parentNode.insertBefore(tag, firstScriptTag); let onPlayerStateChange=function(event){if (event.data==YT.PlayerState.ENDED){playerWrap.classList.add("ended");}else if (event.data==YT.PlayerState.PAUSED){playerWrap.classList.add("paused");}else if (event.data==YT.PlayerState.PLAYING){playerWrap.classList.remove("ended"); playerWrap.classList.remove("paused");}}; let player; onYouTubeIframeAPIReadyCallbacks.push(function(){player=new YT.Player(playerFrame,{events:{'onStateChange': onPlayerStateChange}});}); playerWrap.addEventListener("click", function(){let playerState=player.getPlayerState(); if (playerState==YT.PlayerState.ENDED){player.seekTo(0);}else if (playerState==YT.PlayerState.PAUSED){player.playVideo();}});}window.onYouTubeIframeAPIReady=function(){for (let callback of onYouTubeIframeAPIReadyCallbacks){callback();}}; window.hideYTActivated=true;});</script>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="iot3">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Automatic Gun Fire Control System With Visual
                            Tracking</h2>
                            <p>Security of a nation and its subjects are always been the highest issue of priority for decade
                            of years.Only for that purpose now a days a country’s whole defence system has ingrained with
                            modern science and technology,rapid changes have been made in the war field also. So with
                            the aim of providing aid to the national security,this automatic gun firing control system with
                            visual tracking will provide not only the accurate automatic firing system but also video monitor
                            coverage to track down any moving or static target. This system can be used not only for military
                            purpose, but also for home defense, as well. The main goal of this system is to operate a gun
                            and control the firing system automatically as a defense system to protect a particular area
                            against intruders or attackers. Basically this mechanism will provide area surveillance which
                            will employ image processing in which a camera will be continuously monitoring along with a
                            sonar system for more accuracy of moving target and a thermal sensor for detecting the static
                            target. The system proposed here is the prototype of the automatic intruder detection and
                            gun control to eliminate any threat or any unwanted activity and aid the dangerous missions
                            accurately with high reliability.</p>       
                            <p>In many countries they don’t have any automated gun firing technology. As the military are
                            moving forward so they need automated gun firing system to develop military resources. This
                            automated gun firing system is available in many developed military forces but the system is
                            very costly. So by considering the cost,this system is build with a very low cost and more
                            effective gun firing system for military forces and also for the civil security agencies. And this
                            project will give more efficiency, accuracy and security in addition to the existing system. At
                            the same time, this system will save many personnel in the battle field.</p>
                            <p>This software can be used for military purpose, mostly in military and war environment. Besides other security
                            agents who have the authority to use the weapon can use this to keep different sensitive institutions safe and
                            secured.This system can be used also for the security of military installation. For civilian purpose this system
                            can also be used for private security.]Our projects main objective is to establish an automatic tracking and
                            shooting system. To control the whole system we need a user interface like software from which we can identify
                            the target, track and confirm to shoot the target. Our software is app based and called AGCS. The main
                            benefit of our software is , it is very cost-effective, more accurate and mostly reliable. User can install the
                            whole system including software by spending less amount of money and in less effort. Another benefit is that
                            our software is user friendly. User can control the system using this software without much difficulty.
                            </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>System Architecture:</p>  
                                <img src="assets/images/portfolio/iot301.jpg" alt="" class="img-fluid">
                                <p>Flow Chart:</p> 
                                <img src="assets/images/portfolio/iot302.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/iot303.jpg" alt="" class="img-fluid">        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="robotics1">
                <div class="container">
                    <div class="mh-portfolio-modal-img">
                            <p style="text-align: center;">Line Follower Robot Using IR Color Detection:</p>
                            <style>.hytPlayerWrap{display: inline-block; position: relative;}.hytPlayerWrap.ended::after{content:""; position: absolute; top: 0; left: 0; bottom: 0; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 64px 64px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEwIDUxMCI+PHBhdGggZD0iTTI1NSAxMDJWMEwxMjcuNSAxMjcuNSAyNTUgMjU1VjE1M2M4NC4xNSAwIDE1MyA2OC44NSAxNTMgMTUzcy02OC44NSAxNTMtMTUzIDE1My0xNTMtNjguODUtMTUzLTE1M0g1MWMwIDExMi4yIDkxLjggMjA0IDIwNCAyMDRzMjA0LTkxLjggMjA0LTIwNC05MS44LTIwNC0yMDQtMjA0eiIgZmlsbD0iI0ZGRiIvPjwvc3ZnPg==);}.hytPlayerWrap.paused::after{content:""; position: absolute; top: 70px; left: 0; bottom: 50px; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 40px 40px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEiIHdpZHRoPSIxNzA2LjY2NyIgaGVpZ2h0PSIxNzA2LjY2NyIgdmlld0JveD0iMCAwIDEyODAgMTI4MCI+PHBhdGggZD0iTTE1Ny42MzUgMi45ODRMMTI2MC45NzkgNjQwIDE1Ny42MzUgMTI3Ny4wMTZ6IiBmaWxsPSIjZmZmIi8+PC9zdmc+);}</style><div class="hytPlayerWrapOuter"> <div class="hytPlayerWrap"> <iframe width="640" height="480" src="https://www.youtube.com/embed/X9C4UZPbcj8?rel=0&enablejsapi=1" frameborder="0" ></iframe> </div></div><script>"use strict"; document.addEventListener('DOMContentLoaded', function(){if (window.hideYTActivated) return; let onYouTubeIframeAPIReadyCallbacks=[]; for (let playerWrap of document.querySelectorAll(".hytPlayerWrap")){let playerFrame=playerWrap.querySelector("iframe"); let tag=document.createElement('script'); tag.src="https://www.youtube.com/iframe_api"; let firstScriptTag=document.getElementsByTagName('script')[0]; firstScriptTag.parentNode.insertBefore(tag, firstScriptTag); let onPlayerStateChange=function(event){if (event.data==YT.PlayerState.ENDED){playerWrap.classList.add("ended");}else if (event.data==YT.PlayerState.PAUSED){playerWrap.classList.add("paused");}else if (event.data==YT.PlayerState.PLAYING){playerWrap.classList.remove("ended"); playerWrap.classList.remove("paused");}}; let player; onYouTubeIframeAPIReadyCallbacks.push(function(){player=new YT.Player(playerFrame,{events:{'onStateChange': onPlayerStateChange}});}); playerWrap.addEventListener("click", function(){let playerState=player.getPlayerState(); if (playerState==YT.PlayerState.ENDED){player.seekTo(0);}else if (playerState==YT.PlayerState.PAUSED){player.playVideo();}});}window.onYouTubeIframeAPIReady=function(){for (let callback of onYouTubeIframeAPIReadyCallbacks){callback();}}; window.hideYTActivated=true;});</script>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="robotics2">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>AI Farmer Assistant Robot</h2>
                            <p>The revolution of technology has upgraded our lifestyle in every sector. Now a days, most of
                            the farmers are changing their occupation due to various reasons and thus, the agriculture
                            sector in Bangladesh is facing problems on the way of it’s growth.</p>       
                            <p>This smart farmer assistant robot works with Arduino. Various sensors for soil, air and water
                            are attached with it, which feeds the required data to the Arduino processor. The Arduino
                            processors then determine the condition and decisions to be taken for the specific field.
                            The robot sends primary analyzed data to the mobile device or smartphone of the farmer,
                            so that the farmer can take immediate decisions. Again, the robot sends the data to
                            agriculture research center, or in the central server, which further analyses the data with
                            machine learning algorithm for getting future predictions and probable values and measures
                            to be taken for upgrading the agriculture sector.</p>
                            <p>
                                Advantages:
                                <ol style="list-style-type: disc;">
                                    <li>
                                        Automate multiple processes across crop production cycle, e.g. irrigation, fertilizing, or pest control
                                    </li>
                                    <li>
                                        Increase productivity and net profit
                                    </li>
                                    <li>
                                        Improve water quality
                                    </li>
                                    <li>
                                        Sustain natural resources for generations to come
                                    </li>
                                    <li>
                                        Enhance marketing of farm products
                                    </li>
                                    <li>
                                        Build-up a record of a farm
                                    </li>
                                    <li>
                                        Provides better information to the farmers as well as scientists for making management decision
                                    </li>
                                    <li>
                                        Real-Time monitoring and analysis
                                    </li>
                                    <li>
                                        Reduces fertilizer costs
                                    </li>
                                    <li>
                                        Reduces pesticide costs
                                    </li>
                                    <li>
                                        Reducing Labor, increasing yield and efficiency
                                    </li>
                                    <li>
                                        Reduces pollution as healthy land and quality water, both are becoming a limitation to agricultural productivity
                                    </li>
                                </ol>
                            </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <p>Working Principle:</p>
                                <img src="assets/images/portfolio/robotics201.jpg" alt="" class="img-fluid">
                                <img src="assets/images/portfolio/robotics202.jpg" alt="" class="img-fluid">         
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="robotics3">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">RC Robots:</p>
                            <img src="assets/images/portfolio/robotics301.jpg" style="max-width: 100%;"><br><br>
                            <style>.hytPlayerWrap{display: inline-block; position: relative;}.hytPlayerWrap.ended::after{content:""; position: absolute; top: 0; left: 0; bottom: 0; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 64px 64px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEwIDUxMCI+PHBhdGggZD0iTTI1NSAxMDJWMEwxMjcuNSAxMjcuNSAyNTUgMjU1VjE1M2M4NC4xNSAwIDE1MyA2OC44NSAxNTMgMTUzcy02OC44NSAxNTMtMTUzIDE1My0xNTMtNjguODUtMTUzLTE1M0g1MWMwIDExMi4yIDkxLjggMjA0IDIwNCAyMDRzMjA0LTkxLjggMjA0LTIwNC05MS44LTIwNC0yMDQtMjA0eiIgZmlsbD0iI0ZGRiIvPjwvc3ZnPg==);}.hytPlayerWrap.paused::after{content:""; position: absolute; top: 70px; left: 0; bottom: 50px; right: 0; cursor: pointer; background-color: black; background-repeat: no-repeat; background-position: center; background-size: 40px 40px; background-image: url(data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEiIHdpZHRoPSIxNzA2LjY2NyIgaGVpZ2h0PSIxNzA2LjY2NyIgdmlld0JveD0iMCAwIDEyODAgMTI4MCI+PHBhdGggZD0iTTE1Ny42MzUgMi45ODRMMTI2MC45NzkgNjQwIDE1Ny42MzUgMTI3Ny4wMTZ6IiBmaWxsPSIjZmZmIi8+PC9zdmc+);}</style><div class="hytPlayerWrapOuter"> <div class="hytPlayerWrap"> <iframe width="640" height="480" src="https://www.youtube.com/embed/LwKAQX8smVg?rel=0&enablejsapi=1" frameborder="0" ></iframe> </div></div><script>"use strict"; document.addEventListener('DOMContentLoaded', function(){if (window.hideYTActivated) return; let onYouTubeIframeAPIReadyCallbacks=[]; for (let playerWrap of document.querySelectorAll(".hytPlayerWrap")){let playerFrame=playerWrap.querySelector("iframe"); let tag=document.createElement('script'); tag.src="https://www.youtube.com/iframe_api"; let firstScriptTag=document.getElementsByTagName('script')[0]; firstScriptTag.parentNode.insertBefore(tag, firstScriptTag); let onPlayerStateChange=function(event){if (event.data==YT.PlayerState.ENDED){playerWrap.classList.add("ended");}else if (event.data==YT.PlayerState.PAUSED){playerWrap.classList.add("paused");}else if (event.data==YT.PlayerState.PLAYING){playerWrap.classList.remove("ended"); playerWrap.classList.remove("paused");}}; let player; onYouTubeIframeAPIReadyCallbacks.push(function(){player=new YT.Player(playerFrame,{events:{'onStateChange': onPlayerStateChange}});}); playerWrap.addEventListener("click", function(){let playerState=player.getPlayerState(); if (playerState==YT.PlayerState.ENDED){player.seekTo(0);}else if (playerState==YT.PlayerState.PAUSED){player.playVideo();}});}window.onYouTubeIframeAPIReady=function(){for (let callback of onYouTubeIframeAPIReadyCallbacks){callback();}}; window.hideYTActivated=true;});</script>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="design1">
                <div class="container">
                        <div class="mh-portfolio-modal-img">
                            <p style="text-align: center;">Designed Logo:</p>
                            <img src="assets/images/portfolio/design1.jpg" style="max-width: 100%;">
                        </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="design2">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Designed Branding & Promotion Posters:</p>
                            <img src="assets/images/portfolio/design201.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design202.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design203.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design204.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design205.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design206.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="design3">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Designed Products:</p>
                            <img src="assets/images/portfolio/design301.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design302.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design303.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design304.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design305.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="design4">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Event Item Designs:</p>
                            <img src="assets/images/portfolio/design401.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design402.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design403.jpg" style="max-width: 100%;"><br><br>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="design5">
                <div class="container">
                    <div class="mh-portfolio-modal-inner">
                            <p style="text-align: center;">Wireframe & UI Designs:</p>
                            <img src="assets/images/portfolio/design501.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design502.jpg" style="max-width: 100%;"><br><br>
                            <img src="assets/images/portfolio/design503.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
        </section>
        
        <!--INTERESTED TO WORK?-->
        <section class="mh-quates image-bg home-2-img">
            <div class="img-color-overlay">
                <div class="container">
                    <div class="row section-separator">
                        <div class="each-quates col-sm-12 col-md-6">
                            <h3 class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">Interested to Work?</h3>
                            <p class="wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s">Do you want to share some idea with me? or want me to accomplish a project for you? Just feel free to knock me.<br><br>
                            <i>"Most people never pick up the phone and call. Most people never ask. And that’s what separates sometimes the people that do things from the people that just dream about them."<br>
                            -Steve Jobs</i>
                            </p>
                            <a href="#mh-contact" class="btn btn-fill wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">Contact Me</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--FOOTER-->
        <footer class="mh-footer mh-footer-3" id="mh-contact">
            <div class="container-fluid">
                <div class="row section-separator">
                    <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                        <h3>Contact Me</h3>
                    </div>
                    <div class="map-image image-bg col-sm-12">
                        <div class="container mt-30">
                            <div class="row">
                                <div class="col-sm-12 col-md-6 mh-footer-address">
                                    <div class="col-sm-12 xs-no-padding">
                                        <div class="mh-address-footer-item dark-bg shadow-1 media wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                                            <div class="each-icon">
                                                <i class="fa fa-location-arrow"></i>
                                            </div>
                                            <div class="each-info media-body">
                                                <h4>Address</h4>
                                                <address>
                                                    1A/634, Road-9, Avenue-3, Mirpur DOHS <br> 
                                                     Dhaka-1216, Bangladesh
                                                </address>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 xs-no-padding">
                                        <div class="mh-address-footer-item media dark-bg shadow-1 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.4s">
                                            <div class="each-icon">
                                                <i class="fa fa-envelope-o"></i>
                                            </div>
                                            <div class="each-info media-body">
                                                <h4>Email</h4>
                                                <a href="mailto:mahmudulhasan.2524@gmail.com">mahmudulhasan.2524@gmail.com</a><br>
                                                <a href="mailto:hasan.skratch@gmail.com">hasan.skratch@gmail.com</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 xs-no-padding">
                                        <div class="mh-address-footer-item media dark-bg shadow-1 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.6s">
                                            <div class="each-icon">
                                                <i class="fa fa-phone"></i>
                                            </div>
                                            <div class="each-info media-body">
                                                <h4>Phone</h4>
                                                <a href="tel:+8801873472524">+880 1873472524</a><br>
                                                <a href="tel:+8801959031724">+880 1959031724</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                                    <form name="contact-form" id="contact-form" class="single-form quate-form wow fadeInUp" action="mailer.php" method="POST" onsubmit="return validateForm()">
                                        <div id="msgSubmit" class="h3 text-center hidden"></div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <input id="name" name="name" class="contact-name form-control" id="name" type="text" placeholder="Name" required>
                                            </div>
                
                                            <div class="col-sm-12">
                                                <input id="email" name="email" class="contact-email form-control" id="email" type="text" placeholder="Email" required>
                                            </div>
                
                                            <div class="col-sm-12">
                                                <input id="subject" name="subject" class="contact-subject form-control" id="subject" type="text" placeholder="Subject" required>
                                            </div>
                                            
                                            <div class="col-sm-12">
                                                <textarea id="message" class="contact-message" name="message" id="message" rows="6" placeholder="Your Message" required></textarea>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Subject Button -->
                                    <div class="btn-form col-sm-12">
                                        <button type="submit" name="submit" class="btn btn-fill btn-block" onclick="validateForm()">
                                        Send Message</button>
                                    </div><br>
                                    <div class="status" id="status"></div>
                                </div>
                                <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.2s">
                                    <p><br></p>
                                    <p>
                                    <ul class="social-icon">
                                        <li><a href="https://linkedin.com/in/hasan24" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="https://github.com/hasan-24" target="_blank"><i class="fa fa-github"></i></a></li>
                                        <li><a href="https://wa.me/8801873472524" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
                                        <li><a data-fancybox data-src="#wechat"><i class="fa fa-wechat"></i></a></li>
                                    </ul>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="wechat">
                <div class="container">
                    <div class="row mh-portfolio-modal-img">
                        <img src="assets/images/wechat.jpg" style="max-width: 100%;">
                    </div>
                </div>
            </div>
        </footer>

    <!--JS Files-->
    <script src="assets/plugins/js/jquery.min.js"></script>
    <script src="assets/plugins/js/popper.min.js"></script>
    <script src="assets/plugins/js/bootstrap.min.js"></script>
    <script src="assets/plugins/js/owl.carousel.js"></script>
    <script src="assets/plugins/js/wow.min.js"></script>
    <script src="assets/plugins/js/jquery.mixitup.min.js"></script>
    <script src="assets/plugins/js/circle-progress.js"></script>
    <script src="assets/plugins/js/jquery.nav.js"></script>
    <script src="assets/plugins/js/jquery.fancybox.min.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?v=3.exp&amp;key=AIzaSyCRP2E3BhaVKYs7BvNytBNumU0MBmjhhxc"></script>
    <script src="assets/plugins/js/isotope.pkgd.js"></script>
    <script src="assets/plugins/js/packery-mode.pkgd.js"></script>
    <script src="assets/js/map-init.js"></script>
    <script src="assets/js/custom-scripts.js"></script>
    <script>

    function validateForm() {

    document.getElementById('status').innerHTML = "Sending...";
    formData = {
        'name'     : $('input[name=name]').val(),
        'email'    : $('input[name=email]').val(),
        'subject'  : $('input[name=subject]').val(),
        'message'  : $('textarea[name=message]').val()
    };


   $.ajax({
    url : "mailer.php",
    type: "POST",
    data : formData,
    success: function(data, textStatus, jqXHR)
    {

        $('#status').text(data.message);
        if (data.code) //If mail was sent successfully, reset the form.
        $('#contact-form').closest('form').find("input[type=text], textarea").val("");
    },
    error: function (jqXHR, textStatus, errorThrown)
    {
        $('#status').text(jqXHR);
    }
    });
}
    </script>
</body>
</html>